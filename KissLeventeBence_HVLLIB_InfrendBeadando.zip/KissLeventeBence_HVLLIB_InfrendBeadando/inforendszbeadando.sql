-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1:3306
-- Létrehozás ideje: 2022. Ápr 06. 20:46
-- Kiszolgáló verziója: 5.7.36
-- PHP verzió: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `inforendszbeadando`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `loans`
--

DROP TABLE IF EXISTS `loans`;
CREATE TABLE IF NOT EXISTS `loans` (
  `partner_id` int(11) NOT NULL,
  `machine_id` int(11) NOT NULL,
  `startDate` varchar(255) NOT NULL,
  `endDate` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `loans`
--

INSERT INTO `loans` (`partner_id`, `machine_id`, `startDate`, `endDate`, `id`) VALUES
(25, 9, '2022-04-06\r\n', NULL, 19),
(26, 12, '2022-04-06', NULL, 20);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `machines`
--

DROP TABLE IF EXISTS `machines`;
CREATE TABLE IF NOT EXISTS `machines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `performance` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  `deposit` int(11) NOT NULL,
  `rent` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `machines`
--

INSERT INTO `machines` (`id`, `brand`, `name`, `type`, `performance`, `weight`, `deposit`, `rent`) VALUES
(7, 'Husqvarna', 'Fűnyíró', 'LC 253 S', 2, 15, 10000, 1000),
(8, 'Husqvarna', 'Fűnyíró', 'LC 347 V', 3, 20, 10000, 2000),
(9, 'Oleo-Mac', 'Fűkasza', '755 MASTER', 2, 8, 20000, 2000),
(10, 'Honda', 'Fűkasza', 'UMK 755', 3, 6, 30000, 2000),
(11, 'Ferris', 'Fűnyíró traktor', 'IS 400S', 21, 600, 100000, 10000),
(12, 'Hecht', 'Gyepszellőztető', '5654', 2, 10, 20000, 1000),
(13, 'Husqvarna', 'Fűrész', 'K970', 5, 9, 15000, 2000);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `partners`
--

DROP TABLE IF EXISTS `partners`;
CREATE TABLE IF NOT EXISTS `partners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `companyName` varchar(255) NOT NULL,
  `delegateName` varchar(255) NOT NULL,
  `taxNum` varchar(255) NOT NULL,
  `compRegNum` varchar(255) NOT NULL,
  `headquarters` varchar(255) NOT NULL,
  `balance` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `partners`
--

INSERT INTO `partners` (`id`, `companyName`, `delegateName`, `taxNum`, `compRegNum`, `headquarters`, `balance`) VALUES
(24, 'Tesco', 'Kovács András', '12661353-2-45', '01-09-562738', 'Budapest', -2000),
(25, 'Kovács és társa Kft.', 'Tóth Imre', '67315681-2-04', '01-09-234104', 'Miskolc', 15000),
(26, 'Agroker Kft.', 'Mihályi Zoltán', '34581734-4-12', '124157-24-63', 'Eger', 7000),
(27, 'Immodius Kft.', 'Erős Szilárd', '34525624-2-20', '124525-12-65', 'Miskolc', 45000);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE IF NOT EXISTS `transactions` (
  `partnerId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `transactions`
--

INSERT INTO `transactions` (`partnerId`, `type`, `price`, `date`, `id`) VALUES
(24, 'Feltöltés', '15000', '2022-04-06', 27),
(25, 'Feltöltés', '15000', '2022-04-06', 28),
(26, 'Feltöltés', '15000', '2022-04-06', 29),
(27, 'Feltöltés', '15000', '2022-04-06', 30),
(24, 'Feltöltés', '10000', '2022-04-06', 31),
(24, 'Levonás', '6000', '2022-04-06', 32);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

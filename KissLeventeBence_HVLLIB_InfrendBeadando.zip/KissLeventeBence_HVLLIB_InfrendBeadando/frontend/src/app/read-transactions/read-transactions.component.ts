import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-read-transactions',
  templateUrl: './read-transactions.component.html',
  styleUrls: ['./read-transactions.component.css']
})
export class ReadTransactionsComponent implements OnInit {

  constructor(private service:ServiceService, private router:ActivatedRoute) { }

  readedData:any;
  successmsg:any;
  getParamID:any;
  upload:any;

  ngOnInit(): void {
    this.getParamID = this.router.snapshot.paramMap.get('id');
    this.getAllTransactions();
  }

  dateSearchForm = new FormGroup({
    'smallDate': new FormControl('',Validators.required),
    'bigDate': new FormControl('',Validators.required)
  });

  getAllTransactions(){
    this.service.getAllTransactions(this.getParamID).subscribe((res)=>{
      this.readedData = res.data;
    });
  }

  searchByDate(){
    if(this.dateSearchForm.valid){
      this.service.searchTransactionByDate(this.dateSearchForm.get('smallDate')?.value, this.dateSearchForm.get('bigDate')?.value, this.getParamID).subscribe((res)=>{
        this.readedData = res.data;
      });
    }
  }
}

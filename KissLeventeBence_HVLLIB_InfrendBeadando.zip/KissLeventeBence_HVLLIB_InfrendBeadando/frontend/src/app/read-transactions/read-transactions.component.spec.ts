import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadTransactionsComponent } from './read-transactions.component';

describe('ReadTransactionsComponent', () => {
  let component: ReadTransactionsComponent;
  let fixture: ComponentFixture<ReadTransactionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReadTransactionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadTransactionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

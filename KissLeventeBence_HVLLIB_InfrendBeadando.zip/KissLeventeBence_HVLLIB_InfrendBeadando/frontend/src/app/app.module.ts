import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReadMachineComponent } from './read-machine/read-machine.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ReadPartnerComponent } from './read-partner/read-partner.component';
import { HttpClientModule } from '@angular/common/http';
import { CreateMachineComponent } from './create-machine/create-machine.component';
import { CreatePartnerComponent } from './create-partner/create-partner.component';
import { ReadTransactionsComponent } from './read-transactions/read-transactions.component';
import { UploadBalanceComponent } from './upload-balance/upload-balance.component';
import { ReadLoanComponent } from './read-loan/read-loan.component';
import { CreateLoanComponent } from './create-loan/create-loan.component';
import { EndLoanComponent } from './end-loan/end-loan.component';

@NgModule({
  declarations: [
    AppComponent,
    ReadMachineComponent,
    NavbarComponent,
    ReadPartnerComponent,
    CreateMachineComponent,
    CreatePartnerComponent,
    ReadTransactionsComponent,
    UploadBalanceComponent,
    ReadLoanComponent,
    CreateLoanComponent,
    EndLoanComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

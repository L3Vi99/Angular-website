import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadMachineComponent } from './read-machine.component';

describe('ReadMachineComponent', () => {
  let component: ReadMachineComponent;
  let fixture: ComponentFixture<ReadMachineComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReadMachineComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadMachineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

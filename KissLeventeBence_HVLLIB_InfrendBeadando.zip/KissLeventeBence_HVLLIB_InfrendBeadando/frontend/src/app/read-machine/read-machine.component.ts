import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-read-machine',
  templateUrl: './read-machine.component.html',
  styleUrls: ['./read-machine.component.css']
})
export class ReadMachineComponent implements OnInit {

  constructor(private service:ServiceService) { }

  readedData:any;
  successmsg:any;

  ngOnInit(): void {
    this.getAllMachines();
  }

  getAllMachines(){
    this.service.getAllMachine().subscribe((res)=>{
      this.readedData = res.data;
    });
  }

  deleteID(id:any){
    this.service.deleteMachine(id).subscribe((res)=>{
        this.successmsg=res.message;
        this.getAllMachines();
    });
  }


}

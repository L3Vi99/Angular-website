import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateLoanComponent } from './create-loan/create-loan.component';
import { CreateMachineComponent } from './create-machine/create-machine.component';
import { CreatePartnerComponent } from './create-partner/create-partner.component';
import { EndLoanComponent } from './end-loan/end-loan.component';
import { ReadLoanComponent } from './read-loan/read-loan.component';
import { ReadMachineComponent } from './read-machine/read-machine.component';
import { ReadPartnerComponent } from './read-partner/read-partner.component';
import { ReadTransactionsComponent } from './read-transactions/read-transactions.component';
import { UploadBalanceComponent } from './upload-balance/upload-balance.component';

const routes: Routes = [
  { path: '', redirectTo: 'readMachine', pathMatch: 'full' },
  {path:'readMachine', component:ReadMachineComponent},
  {path:'readPartner', component:ReadPartnerComponent},
  {path:'createMachine', component:CreateMachineComponent},
  {path:'createPartner', component:CreatePartnerComponent},
  {path:'createMachine/:id', component:CreateMachineComponent},
  {path:'createPartner/:id', component:CreatePartnerComponent},
  {path:'readTransactions/:id', component:ReadTransactionsComponent},
  {path:'uploadBalance', component:UploadBalanceComponent},
  {path:'createLoan', component:CreateLoanComponent},
  {path:'readLoan', component:ReadLoanComponent},
  {path:'endLoan/:id', component:EndLoanComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

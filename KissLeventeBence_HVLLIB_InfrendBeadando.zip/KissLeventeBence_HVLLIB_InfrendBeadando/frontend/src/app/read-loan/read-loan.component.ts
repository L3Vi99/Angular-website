import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-read-loan',
  templateUrl: './read-loan.component.html',
  styleUrls: ['./read-loan.component.css']
})
export class ReadLoanComponent implements OnInit {

  constructor(private service:ServiceService) { }

  readedData:any;
  successmsg:any;

  ngOnInit(): void {
    this.getAllLoans();
  }

  getAllLoans(){
    this.service.getAllLoan().subscribe((res)=>{
      this.readedData = res.data;
    });
  }

}

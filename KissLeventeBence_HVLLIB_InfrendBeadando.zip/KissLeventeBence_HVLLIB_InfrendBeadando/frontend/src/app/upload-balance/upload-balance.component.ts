import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-upload-balance',
  templateUrl: './upload-balance.component.html',
  styleUrls: ['./upload-balance.component.css']
})
export class UploadBalanceComponent implements OnInit {

  errormsg:any;
  success:any;
  selectedPartnerOption:any;
  printedPartnerOption:any;
  readedDataPartner:any;
  canUpload:any;

  constructor(private service:ServiceService) { }

  ngOnInit(): void {
    this.getPartnerIdAndName();
  }

  balanceForm = new FormGroup({
    'balance': new FormControl('',Validators.required)
  });

  uploadBalance(){
    this.printedPartnerOption = this.selectedPartnerOption;
    if(this.isSelectOk(this.printedPartnerOption)){
      if(this.balanceForm.valid){
        this.service.uploadBalance(this.printedPartnerOption,this.balanceForm.value).subscribe((res)=>{
        });
        this.service.addTransaction(this.printedPartnerOption,"Feltöltés", this.balanceForm.value).subscribe((res)=>{
        });
      }
      this.success="Sikeres feltöltés"
    }
    
  }

  getPartnerIdAndName(){
    this.service.getPartnerIdAndName().subscribe((res)=>{
      this.readedDataPartner = res.data;
    });
  }

  isSelectOk(a:any){
    this.canUpload=false;
    if(isNaN(a)){
      this.errormsg='Választani kell egy ügyfelet!';
    }else{
      this.canUpload=true;
      this.errormsg='';
    }
    return this.canUpload;
  }

}

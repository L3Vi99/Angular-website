import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-create-loan',
  templateUrl: './create-loan.component.html',
  styleUrls: ['./create-loan.component.css']
})
export class CreateLoanComponent implements OnInit {

  errormsg:any;
  success:any;
  readedDataMachine:any;
  readedDataPartner:any;
  selectedPartnerOption:any;
  printedPartnerOption:any;
  selectedMachineOption:any;
  printedMachineOption:any;
  canLoan:any;
  balance:any;
  maxDebt = -50000;

  constructor(private service:ServiceService) { }

  ngOnInit(): void {
    this.getMachineIdAndName();
    this.getPartnerIdAndName();
  }

  loanSubmit(){
    this.printedPartnerOption = this.selectedPartnerOption;
    this.printedMachineOption = this.selectedMachineOption;
    this.service.getBalance(this.printedPartnerOption).subscribe((res)=>{
      this.balance=res.data[0].balance;
      if(this.isLoanOk(this.printedPartnerOption,this.printedMachineOption)){
        this.service.insertLoan(this.printedPartnerOption, this.printedMachineOption).subscribe((res)=>{
        });
        this.success = "Sikeres kölcsönzés"
      }
      
    });
  }

  getMachineIdAndName(){
    this.service.getMachineIdAndName().subscribe((res)=>{
      this.readedDataMachine = res.data;
    });
  }

  getPartnerIdAndName(){
    this.service.getPartnerIdAndName().subscribe((res)=>{
      this.readedDataPartner = res.data;
    });
  }

  isLoanOk(a:any, b:any){
    this.canLoan=false;
    if(isNaN(a)){
      this.errormsg='Választani kell egy ügyfelet!';
    }else if(isNaN(b)){
      this.errormsg='Választani kell egy gépet';
    }else if(this.balance<this.maxDebt){
      this.errormsg='A partnernek túl nagy a tartozása!';
    }else{
      this.canLoan=true;
      this.errormsg='';
    }
    return this.canLoan;
  }


}

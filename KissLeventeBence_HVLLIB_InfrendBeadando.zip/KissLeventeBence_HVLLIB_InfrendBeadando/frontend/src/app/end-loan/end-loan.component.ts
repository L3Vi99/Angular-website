import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-end-loan',
  templateUrl: './end-loan.component.html',
  styleUrls: ['./end-loan.component.css']
})
export class EndLoanComponent implements OnInit {

  constructor(private service:ServiceService,private router:ActivatedRoute) { }

  errormsg:any;
  successmsg:any;
  partnerId:any;
  machineId:any;
  partnerData:any;
  getParamID:any;
  sumToPay=0;
  checkboxError:any;
  endDate:any;
  startDate:any;
  days:any;

  ngOnInit(): void {
    this.getParamID = this.router.snapshot.paramMap.get('id');
  }

  loanForm = new FormGroup({
    'companyName': new FormControl('',Validators.required),
    'delegateName': new FormControl('',Validators.required),
    'taxNum': new FormControl('',Validators.required),
    'compRegNum': new FormControl('', Validators.required),
    'headquarters': new FormControl('', Validators.required)
  });

  calculate(){
    this.service.getMachineId(this.getParamID).subscribe((res)=>{
      this.machineId = res.data[0].machine_id;
      this.startDate = res.data[0].startDate;
      this.partnerId = res.data[0].partner_id;
      this.service.getSingleMachine(this.machineId).subscribe((res)=>{
        let date1: Date = new Date(this.endDate);
        let date2: Date = new Date(this.startDate);
        let timeInMilisec=Math.abs(date1.getTime() - date2.getTime());
        this.days = Math.ceil(timeInMilisec / (1000 * 60 * 60 * 24))+1;
        this.sumToPay=res.data[0].rent*this.days;
        if(this.checkboxError==true){
          this.sumToPay=this.sumToPay+res.data[0].deposit;
        }

      });
    });
  }

  submitLoanEnd(){
    if(this.sumToPay==0){
      this.errormsg='Elősször ki kell számoltatni a végösszeget!'
    }
    this.sumToPay = this.sumToPay*-1;
    this.service.uploadBalance2(this.partnerId,this.sumToPay).subscribe((res)=>{
    });
    this.service.deleteLoan(this.getParamID).subscribe((res)=>{
    });
    this.sumToPay = Math.abs(this.sumToPay);
    this.service.addTransaction2(this.partnerId,"Levonás",this.sumToPay).subscribe((res)=>{
      this.successmsg = "Sikeres lezárás"
    });
    
  }
}

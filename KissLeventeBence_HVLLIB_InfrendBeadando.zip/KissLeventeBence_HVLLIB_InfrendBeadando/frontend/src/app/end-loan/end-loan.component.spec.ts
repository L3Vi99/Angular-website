import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EndLoanComponent } from './end-loan.component';

describe('EndLoanComponent', () => {
  let component: EndLoanComponent;
  let fixture: ComponentFixture<EndLoanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EndLoanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EndLoanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

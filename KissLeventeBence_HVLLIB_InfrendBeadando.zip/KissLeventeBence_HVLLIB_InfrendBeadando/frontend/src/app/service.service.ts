import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(private http:HttpClient) { }

  readMachineURL = 'http://localhost:3000/readMachine';
  deleteMachineURL = 'http://localhost:3000/deleteMachine';
  createMachineURL = 'http://localhost:3000/createMachine';
  updateMachineURL = 'http://localhost:3000/updateMachine';
  readPartnerURL = 'http://localhost:3000/readPartner';
  deletePartnerURL = 'http://localhost:3000/deletePartner';
  createPartnerURL = 'http://localhost:3000/createPartner';
  updatePartnerURL = 'http://localhost:3000/updatePartner';
  getNextIdURL = 'http://localhost:3000/returnNextId';
  transactionInitURL = 'http://localhost:3000/transactionInit';
  transactionURL = 'http://localhost:3000/transaction';
  readTransactionURL = 'http://localhost:3000/readTransaction';
  searchTransactionURL = 'http://localhost:3000/searchTransaction';
  getPartnerIdAndNameUrl = 'http://localhost:3000/getPartnerIdAndName';
  getMachineIdAndNameUrl = 'http://localhost:3000/getMachineIdAndName';
  setBalanceUrl = 'http://localhost:3000/setBalance';
  insertLoanURL = 'http://localhost:3000/insertLoan';
  getBalanceURL = 'http://localhost:3000/getBalance';
  readLoanURL = 'http://localhost:3000/readLoan';
  deleteTransactionURL = 'http://localhost:3000/deleteTransaction';
  getMachineIdURL = 'http://localhost:3000/getMachineId';
  deleteLoanURL = 'http://localhost:3000/deleteLoan';

  //get all machine
  getAllMachine():Observable<any>{
    return this.http.get(`${this.readMachineURL}`);
  }

  //delete machine
  deleteMachine(id:any):Observable<any>{
    let ids = id;
    return this.http.delete(`${this.deleteMachineURL}/${ids}`);
  }

  //create machine
  createMachine(data:any):Observable<any>{
    return this.http.post(`${this.createMachineURL}`,data);
  }
  
  //get single machine
  getSingleMachine(id:any):Observable<any>{
    let ids = id;
    return this.http.get(`${this.readMachineURL}/${ids}`);
  }

  //update machine
  updateMachine(data:any,id:any):Observable<any>{
    let ids = id;
    return this.http.put(`${this.updateMachineURL}/${ids}`,data);
  }

  //get all partner
  getAllPartners():Observable<any>{
    return this.http.get(`${this.readPartnerURL}`);
  }

   //delete partner
   deletePartner(id:any):Observable<any>{
    let ids = id;
    return this.http.delete(`${this.deletePartnerURL}/${ids}`);
  }

  //createPartner
  createPartner(data:any):Observable<any>{
    return this.http.post(`${this.createPartnerURL}`,data);
  }

  //update partner
  updatePartner(data:any,id:any):Observable<any>{
    let ids = id;
    return this.http.put(`${this.updatePartnerURL}/${ids}`,data);
  }

  //get single partner
  getSinglePartner(id:any):Observable<any>{
    let ids = id;
    return this.http.get(`${this.readPartnerURL}/${ids}`);
  }

  //return Next Id
  getNextId():Observable<any>{
    return this.http.get(`${this.getNextIdURL}`);
  }

  //add transaction
  addTransactionInit(nextId:any,trans:any):Observable<any>{
    var jsonObject = {"nextId":`${nextId}`,"trans":`${trans}`};
    
    return this.http.post(`${this.transactionInitURL}`,jsonObject);
  }

  addTransaction(nextId:any,trans:any, balanceFrom:any):Observable<any>{
    let balance = balanceFrom.balance;
    var jsonObject = {"nextId":`${nextId}`,"trans":`${trans}`,"balance":`${balance}`};
    return this.http.post(`${this.transactionURL}`,jsonObject);
  }

  addTransaction2(nextId:any,trans:any, balance:any):Observable<any>{
    var jsonObject = {"nextId":`${nextId}`,"trans":`${trans}`,"balance":`${balance}`};
    return this.http.post(`${this.transactionURL}`,jsonObject);
  }

  //get all transactions
  getAllTransactions(id:any):Observable<any>{
    let ids = id;  
    return this.http.get(`${this.readTransactionURL}/${ids}`);
  }

  //search by date
  searchTransactionByDate(smallDate:any, bigDate:any, id:any):Observable<any>{
    var jsonObject = {"smallDate":`${smallDate}`,"bigDate":`${bigDate}`,"id":`${id}`};
    return this.http.post(`${this.searchTransactionURL}`, jsonObject)
  }

  //get partner id and name
  getPartnerIdAndName():Observable<any>{
    return this.http.get(`${this.getPartnerIdAndNameUrl}`);
  }

  //get partner id and name
  getMachineIdAndName():Observable<any>{
    return this.http.get(`${this.getMachineIdAndNameUrl}`);
  }

  //upload balance
  uploadBalance(id:any, balanceForm:any):Observable<any>{
    let balance = balanceForm.balance;
    
    let jsonObject = {"id":id,"balance":balance};
    return this.http.put(`${this.setBalanceUrl}`, jsonObject);
  }

  //upload balance when end
  uploadBalance2(id:any, balance:any):Observable<any>{      
    let jsonObject = {"id":id,"balance":balance};
    return this.http.put(`${this.setBalanceUrl}`, jsonObject);
  }

  //insertLoan
  insertLoan(partner_id:any, machine_id:any):Observable<any>{
    let jsonObject = {"partnerId":partner_id, "machineId":machine_id};
    return this.http.post(`${this.insertLoanURL}`, jsonObject);
  }

  //getbalance
  getBalance(partner_id:any):Observable<any>{
    let jsonObject = {"partnerId":partner_id};
    return this.http.post(`${this.getBalanceURL}`,jsonObject);
  }

  //getAllLoan
  getAllLoan():Observable<any>{
    return this.http.get(`${this.readLoanURL}`);
  }

  //deleteTransactions
  deleteTransactions(id:any):Observable<any>{
    let ids = id;
    return this.http.delete(`${this.deleteTransactionURL}/${ids}`);
  }

  //get partner id
  getMachineId(id:any):Observable<any>{
    let ids = id;
    return this.http.get(`${this.getMachineIdURL}/${ids}`);
  }

  //deleteLoan
  deleteLoan(id:any):Observable<any>{
    let ids = id;
    
    return this.http.delete(`${this.deleteLoanURL}/${ids}`);
  }

}

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-create-machine',
  templateUrl: './create-machine.component.html',
  styleUrls: ['./create-machine.component.css']
})
export class CreateMachineComponent implements OnInit {

  errormsg:any;
  successmsg:any;
  getParamID:any;

  constructor(private service:ServiceService, private router:ActivatedRoute) { }

  ngOnInit(): void {
    this.getParamID = this.router.snapshot.paramMap.get('id');
    if(this.getParamID){

      this.service.getSingleMachine(this.getParamID).subscribe((res)=>{
        this.machineCreateForm.patchValue({
          brand: res.data[0].brand,
          name: res.data[0].name,
          type: res.data[0].type,
          performance: res.data[0].performance,
          weight: res.data[0].weight,
          deposit: res.data[0].deposit,
          rent: res.data[0].rent
        });
        
      });
    }
  }

  machineCreateForm = new FormGroup({
    'brand': new FormControl('',Validators.required),
    'name': new FormControl('',Validators.required),
    'type': new FormControl('',Validators.required),
    'performance': new FormControl('', Validators.required),
    'weight': new FormControl('', Validators.required),
    'deposit': new FormControl('', Validators.required),
    'rent': new FormControl('', Validators.required)
  });

  machineSubmit(){
    if(this.machineCreateForm.valid){
      this.service.createMachine(this.machineCreateForm.value).subscribe((res)=>{
        this.errormsg='';
        this.successmsg = res.message;
      });

    }else {
      this.errormsg = 'Helytelen kitöltés!';
    }
  }

  machineUpdate(){
    if(this.machineCreateForm.valid){
      this.service.updateMachine(this.machineCreateForm.value, this.getParamID).subscribe((res)=>{
        this.successmsg=res.message;
        this.errormsg='';
      });
    }else{
      this.errormsg='Hibás kitöltés';
    }
  }



}

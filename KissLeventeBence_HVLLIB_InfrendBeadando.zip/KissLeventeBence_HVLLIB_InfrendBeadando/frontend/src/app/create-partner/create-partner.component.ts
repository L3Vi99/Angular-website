import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-create-partner',
  templateUrl: './create-partner.component.html',
  styleUrls: ['./create-partner.component.css']
})
export class CreatePartnerComponent implements OnInit {

  constructor(private service:ServiceService, private router:ActivatedRoute) { }

  errormsg:any;
  successmsg:any;
  getParamID:any;
  nextId:any;
  trans = "Feltöltés";

  ngOnInit(): void {
    this.getParamID = this.router.snapshot.paramMap.get('id');
    if(this.getParamID){

      this.service.getSinglePartner(this.getParamID).subscribe((res)=>{
        console.log(res);
        
        this.partnerCreateForm.patchValue({
          companyName: res.data[0].companyName,
          delegateName: res.data[0].delegateName,
          taxNum: res.data[0].taxNum,
          compRegNum: res.data[0].compRegNum,
          headquarters: res.data[0].headquarters,
        });
        
      });
    }
  }

  partnerCreateForm = new FormGroup({
    'companyName': new FormControl('',Validators.required),
    'delegateName': new FormControl('',Validators.required),
    'taxNum': new FormControl('',Validators.required),
    'compRegNum': new FormControl('', Validators.required),
    'headquarters': new FormControl('', Validators.required)
  });

  partnerSubmit(){
    if(this.partnerCreateForm.valid){
      this.service.getNextId().subscribe((res)=>{
        this.nextId = res.data[0].AUTO_INCREMENT;
        this.service.addTransactionInit(this.nextId, this.trans).subscribe((res)=>{
        });
        this.service.createPartner(this.partnerCreateForm.value).subscribe((res)=>{
          this.errormsg='';
          this.successmsg = res.message;
        });
  
      });
      
    }else {
      this.errormsg = 'Helytelen kitöltés!';
    }
  }

  partnerUpdate(){
    if(this.partnerCreateForm.valid){
      this.service.updatePartner(this.partnerCreateForm.value, this.getParamID).subscribe((res)=>{
        this.successmsg=res.message;
        this.errormsg='';
      });
    }else{
      this.errormsg='Hibás kitöltés';
    }
  }

}

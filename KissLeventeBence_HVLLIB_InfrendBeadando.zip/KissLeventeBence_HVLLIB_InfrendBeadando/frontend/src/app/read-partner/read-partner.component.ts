import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-read-partner',
  templateUrl: './read-partner.component.html',
  styleUrls: ['./read-partner.component.css']
})
export class ReadPartnerComponent implements OnInit {

  constructor(private service:ServiceService) { }

  readedData:any;
  successmsg:any;

  ngOnInit(): void {
    this.getAllPartners();
  }

  getAllPartners(){
    this.service.getAllPartners().subscribe((res)=>{
      this.readedData = res.data;
    });
  }

  deleteID(id:any){
    this.service.deletePartner(id).subscribe((res)=>{
        this.successmsg=res.message;
        this.getAllPartners();
    });
    this.service.deleteTransactions(id).subscribe((res)=>{
    });
  }

}

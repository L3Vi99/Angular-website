import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Partners{
    @PrimaryGeneratedColumn()
    id:number;
    @Column()
    companyName:string;
    @Column()
    delegateName:string;
    @Column()
    taxNum:string;
    @Column()
    compRegNum:string;
    @Column()
    headquarters:string;
    @Column()
    balance:number;
}
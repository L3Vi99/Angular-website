import { Column, Entity, Generated, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Loans{
    @Column()
    partner_id:number;
    @Column()
    machine_id:number;
    @Column()
    startDate:string;
    @Column({nullable:true})
    endDate:string;
    @PrimaryGeneratedColumn()
    id:number;
}
import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Transactions{
    @Column()
    partnerId:number;
    @Column()
    type:string;
    @Column()
    price:string;
    @Column()
    date:string;
    @PrimaryGeneratedColumn()
    id:number;
}
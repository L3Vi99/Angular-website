import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Machines{
    @PrimaryGeneratedColumn()
    id:number;
    @Column()
    brand:string;
    @Column()
    name:string;
    @Column()
    type:string;
    @Column()
    performance:number;
    @Column()
    weight:number;
    @Column()
    deposit:number;
    @Column()
    rent:number;

}
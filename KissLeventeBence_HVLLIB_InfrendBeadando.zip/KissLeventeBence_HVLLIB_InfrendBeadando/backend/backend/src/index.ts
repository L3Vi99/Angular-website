import { stringify } from "querystring";
import "reflect-metadata";
import {createConnection } from "typeorm";
import { Loans } from "./entity/loans";
import { Machines } from "./entity/machine";
import { Partners } from "./entity/partners";
import { Transactions } from "./entity/transactions";
import { Users } from "./entity/users";

const express = require('express');
const bodyparser = require('body-parser');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(bodyparser.json());

app.listen(3000,() =>{
    console.log("server running...");
});

createConnection({
    type: "mysql",
    host: "localhost",
    port: 3306,
    username: "admin",
    password: "admin",
    database: "inforendszbeadando",
    entities: [
        __dirname + '/entity/**/*.ts'
    ],
    synchronize: true,
    logging: false
}).then(connection => {
    let machineRepository = connection.getRepository(Machines);
    let partnerRepository = connection.getRepository(Partners);
    let trasactionRepository = connection.getRepository(Transactions);
    let userRepository = connection.getRepository(Users);
    let loanRepository = connection.getRepository(Loans);

    app.get('/readMachine',(req,res)=>{
        
        let savedMachines = machineRepository.find();
        savedMachines.then(function(result){
            if(result.length>0){
                res.send({
                    message:'All machine data',
                    data:result
                });
            }else {
                res.send({
                    message:'Error or no data in table'
                })
            }
        })
    })

    //DeleteMachine
    app.delete('/deleteMachine/:id',(req,res)=>{
        let qID = req.params.id;

        machineRepository.query(`delete from machines where id = ${qID}`);
            res.send({
                message:'Sikeres törlés!'
            })
    });
    
    //CreateMachine
    app.post('/createMachine',(req,res)=>{

        let brand = req.body.brand;
        let name = req.body.name;
        let type = req.body.type;
        let performance = req.body.performance;
        let weight = req.body.weight;
        let deposit = req.body.deposit;
        let rent = req.body.rent;

        machineRepository.query(`insert into machines(brand,name,type,performance,weight,deposit,rent)
        values ('${brand}','${name}','${type}',${performance},${weight},${deposit},${rent})`);

        res.send({
            message: 'Sikeres feltöltés!',  
        });
    });

    //ReadMachine
    app.get('/readMachine/:id',(req,res)=>{
        let gID = req.params.id;
    
        let machine = machineRepository.query(`select * from machines where id = ${gID}`);
        machine.then(function(result){
    
            if(result.length>0){
                res.send({
                    message:'Get single data',
                    data:result
                });
            }
            else{
                res.send({
                    message:'Data not found'
                });
            }
        });
    });

    //UpdateMachine
    app.put('/updateMachine/:id',(req,res)=>{

        let gID = req.params.id;
        let brand = req.body.brand;
        let name = req.body.name;
        let type = req.body.type;
        let performance = req.body.performance;
        let weight = req.body.weight;
        let deposit = req.body.deposit;
        let rent = req.body.rent;

        let qr = machineRepository.query(`update machines set brand = '${brand}',name='${name}' ,type='${type}', performance='${performance}',weight='${weight}',deposit='${deposit}',rent='${rent}' where id = ${gID}`);
        res.send({
            message: 'Sikeres módosítás!'
        });
    });

    //ReadPartner
    app.get('/readPartner',(req,res)=>{
        
        let savedMachines = partnerRepository.find();
        savedMachines.then(function(result){
            if(result.length>0){
                res.send({
                    message:'All partner data',
                    data:result
                });
            }else {
                res.send({
                    message:'Error or no data in table'
                })
            }
        })
    })

    //DeletePartner
    app.delete('/deletePartner/:id',(req,res)=>{
        let qID = req.params.id;

        partnerRepository.query(`delete from partners where id = ${qID}`);
            res.send({
                message:'Sikeres törlés!'
            })
    });

    //CreatePartner
    app.post('/createPartner',(req,res)=>{
        let companyName = req.body.companyName;
        let delegateName = req.body.delegateName;
        let taxNum = req.body.taxNum;
        let compRegNum = req.body.compRegNum;
        let headquarters = req.body.headquarters;        

        partnerRepository.query(`insert into partners(companyName,delegateName,taxNum,compRegNum,headquarters,balance)
        values ('${companyName}','${delegateName}','${taxNum}','${compRegNum}','${headquarters}',15000)`);

        res.send({
            message: 'Sikeres feltöltés!',  
        });

    });

    //NextID
    app.get('/returnNextId',(req,res)=>{
        let id = trasactionRepository.query('SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = "inforendszbeadando" AND TABLE_NAME = "partners"');
        id.then(function(result){
            if(result.length>0){
                res.send({
                    message:'Next Id',
                    data:result
                });
            }else {
                res.send({
                    message:'Error or no data in table'
                })
            }
        })
    });

    //Transaction alap létra hozzás
    app.post('/transactionInit',(req,res)=>{
        let nextId = req.body.nextId;
        let trans = req.body.trans;
        var dt = new Date();

        let year  = dt.getFullYear();
        let month = (dt.getMonth() + 1).toString().padStart(2, "0");
        let day   = dt.getDate().toString().padStart(2, "0");
        let date = year+"-"+month+"-"+day;
        trasactionRepository.query(`insert into transactions(partnerId, type, price,date) values (${nextId}, '${trans}', 15000, '${date}')`)
        res.send({
            message: 'Sikeres feltöltés!',  
         });
    });

    //Tranzakció hozzáadás
    app.post('/transaction',(req,res)=>{
        let nextId = req.body.nextId;
        let trans = req.body.trans;
        let balance = req.body.balance;
       
        let date = getTodayDate();
        trasactionRepository.query(`insert into transactions(partnerId, type, price,date) values (${nextId}, '${trans}', ${balance}, '${date}')`)
        res.send({
            message: 'Sikeres feltöltés!',  
         });
    });

    //ReadPartner
    app.get('/readPartner/:id',(req,res)=>{
        let gID = req.params.id;
    
        let partner = partnerRepository.query(`select * from partners where id = ${gID}`);
        partner.then(function(result){
    
            if(result.length>0){
                res.send({
                    message:'Get single data',
                    data:result
                });
            }
            else{
                res.send({
                    message:'Data not found'
                });
            }
        });
    });

    //UpdatePartner
    app.put('/updatePartner/:id',(req,res)=>{

        let gID = req.params.id;
        let companyName = req.body.companyName;
        let delegateName = req.body.delegateName;
        let taxNum = req.body.taxNum;
        let compRegNum = req.body.compRegNum;
        let headquarters = req.body.headquarters;

        let qr = partnerRepository.query(`update partners set companyName = '${companyName}',delegateName='${delegateName}' ,taxNum='${taxNum}', compRegNum='${compRegNum}',headquarters='${headquarters}' where id = ${gID}`);
        res.send({
            message: 'Sikeres módosítás!'
        });
    });

    //ReadTrans
    app.get('/readTransaction/:id',(req,res)=>{
        let gID = req.params.id;
    
        let transaction = trasactionRepository.query(`select * from transactions where partnerId = ${gID}`);
        transaction.then(function(result){
    
            if(result.length>0){
                res.send({
                    message:'Get data',
                    data:result
                });
            }
            else{
                res.send({
                    message:'Data not found'
                });
            }
        });
    });

    //Tranzakció keresés
    app.post('/searchTransaction',(req,res)=>{
        let smallDate = req.body.smallDate;
        let bigDate = req.body.bigDate;
        let id = req.body.id;
        
        let transactions = trasactionRepository.query(`select * from transactions where partnerId=${id} and date between '${smallDate}' and '${bigDate}'`)
        transactions.then(function(result){
    
            if(result.length>0){
                res.send({
                    message:'Get data',
                    data:result
                });
            }
            else{
                res.send({
                    message:'Data not found'
                });
            }
        });
    });

    //Partner ID Név
    app.get('/getPartnerIdAndName',(req,res)=>{
        
        let partner = partnerRepository.query(`select id,companyName from partners`);
        partner.then(function(result){
            if(result.length>0){
                res.send({
                    message:'Partner id and name',
                    data:result
                });
            }else {
                res.send({
                    message:'Error or no data in table'
                })
            }
        });
    });

    //Machine ID Név
    app.get('/getMachineIdAndName',(req,res)=>{
        
        let partner = partnerRepository.query(`SELECT t1.id, t1.name FROM machines t1 LEFT JOIN loans t2 ON t2.machine_id = t1.id WHERE t2.machine_id IS NULL`);
        partner.then(function(result){
            if(result.length>0){
                res.send({
                    message:'Machine id and name',
                    data:result
                });
            }else {
                res.send({
                    message:'Error or no data in table'
                })
            }
        });
    });

    //Machine ID
    app.get('/getMachineId/:id',(req,res)=>{
        let gID = req.params.id;
    
        let loan = loanRepository.query(`select machine_id,partner_id,startDate from loans where id = ${gID}`);
        loan.then(function(result){
    
            if(result.length>0){
                res.send({
                    message:'Get partner,startDate id',
                    data:result
                });
            }
            else{
                res.send({
                    message:'Data not found'
                });
            }
        });
    });


    //Egynelegetfrissít
    app.put('/setBalance',(req,res)=>{
        let balance = req.body.balance;
        let id = req.body.id;
        
        partnerRepository.query(`update partners set balance = balance + '${balance}' where id = ${id}`)
    
        res.send("Sikeres feltöltés");
    });

    //Egyenleglekérdez
    app.post('/getBalance',(req,res)=>{
        let id = req.body.partnerId;
        
        let partner = partnerRepository.query(`select balance from partners where id = ${id}`);
        partner.then(function(result){
            if(result.length>0){
                res.send({
                    message:'Balance',
                    data:result
                });
            }else {
                res.send({
                    message:'Error or no data in table'
                })
            }
        });
    });


    //ÚjKölcsönzés
    app.post('/insertLoan',(req,res)=>{
        let partnerId = req.body.partnerId;
        let machineId = req.body.machineId;
        let date = getTodayDate();
        loanRepository.query(`insert into loans (partner_id, machine_id, startDate, endDate) values ('${partnerId}','${machineId}', '${date}', null)`);

        res.send("Sikeres feltöltés");
    });
    
    //ReadLoan
    app.get('/readLoan',(req,res)=>{
        
        let savedLoans = loanRepository.find();
        savedLoans.then(function(result){
            if(result.length>0){
                res.send({
                    message:'All loan data',
                    data:result
                });
            }else {
                res.send({
                    message:'Error or no data in table'
                })
            }
        })
    })

    //DeleteTrans
    app.delete('/deleteTransaction/:id',(req,res)=>{
        let qID = req.params.id;

        partnerRepository.query(`delete from transactions where partnerId = ${qID}`);
            res.send({
                message:'Sikeres törlés!'
            })
    });

    //LoanDelete
    app.delete('/deleteLoan/:id',(req,res)=>{
        let qID = req.params.id;

        partnerRepository.query(`delete from loans where id = ${qID}`);
            res.send({
                message:'Sikeres törlés!'
            })
    });

}).catch(error => console.log(error));

function getTodayDate(){
    var dt = new Date();

    let year  = dt.getFullYear();
    let month = (dt.getMonth() + 1).toString().padStart(2, "0");
    let day   = dt.getDate().toString().padStart(2, "0");
    let date = year+"-"+month+"-"+day;
    return date;
}